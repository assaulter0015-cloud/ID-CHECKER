/*
 * Adds a batch controller around the extension's existing per-account check
 * buttons. The original check code remains the single source of truth for
 * logging in and deciding each account's status.
 */
(() => {
  'use strict';

  const CHECK_TIMEOUT_MS = 22000;
  const NEXT_CHECK_DELAY_MS = 500;

  const startButton = document.getElementById('checkAllAccountsBtn');
  const stopButton = document.getElementById('stopBulkCheckBtn');
  const progress = document.getElementById('bulkCheckProgress');
  const hint = document.getElementById('bulkCheckHint');

  if (!startButton || !stopButton || !progress || !hint) {
    return;
  }

  const state = {
    isRunning: false,
    queue: [],
    index: 0,
    completed: 0,
    skipped: 0,
    current: null,
    waitTimer: null,
    nextTimer: null,
    activeTabId: null
  };

  const getCheckButtons = () => Array.from(
    document.querySelectorAll('button[data-action="check"][data-id]')
  );

  const getCheckButton = (accountId) => getCheckButtons().find(
    (button) => button.dataset.id === accountId
  );

  const setMessage = (progressText, hintText) => {
    progress.textContent = progressText;
    hint.textContent = hintText;
  };

  const updateControls = () => {
    startButton.disabled = state.isRunning;
    stopButton.disabled = !state.isRunning;
  };

  const clearPendingTimers = () => {
    if (state.waitTimer) {
      window.clearInterval(state.waitTimer);
      state.waitTimer = null;
    }

    if (state.nextTimer) {
      window.clearTimeout(state.nextTimer);
      state.nextTimer = null;
    }
  };

  const finish = (message, detail) => {
    clearPendingTimers();
    state.isRunning = false;
    state.current = null;
    state.activeTabId = null;
    updateControls();
    setMessage(message, detail);
  };

  const accountStatusText = (button) => {
    const accountCard = button.closest('.account-item');
    return accountCard?.querySelector('.account-status')?.textContent?.trim() || '';
  };

  const startNextCheck = () => {
    if (!state.isRunning) {
      return;
    }

    while (state.index < state.queue.length) {
      const accountId = state.queue[state.index];
      const checkButton = getCheckButton(accountId);

      state.index += 1;

      // Do not interfere with a check the user already started manually.
      if (!checkButton || checkButton.disabled) {
        state.skipped += 1;
        continue;
      }

      runCheck(checkButton, accountId);
      return;
    }

    const skippedText = state.skipped ? ` (${state.skipped} skipped)` : '';
    finish(
      `Complete: ${state.completed}/${state.queue.length} checked${skippedText}`,
      'All available saved IDs have been checked.'
    );
  };

  const completeCurrentCheck = () => {
    if (!state.isRunning || !state.current) {
      return;
    }

    clearPendingTimers();
    state.completed += 1;
    setMessage(
      `Checked ${state.completed}/${state.queue.length}`,
      'Moving to the next saved ID…'
    );

    state.current = null;
    state.activeTabId = null;
    state.nextTimer = window.setTimeout(startNextCheck, NEXT_CHECK_DELAY_MS);
  };

  const runCheck = (checkButton, accountId) => {
    let observedBusy = checkButton.disabled;
    const startedAt = Date.now();

    state.current = { accountId, checkButton };
    state.activeTabId = null;
    setMessage(
      `Checking ${state.completed + 1}/${state.queue.length}`,
      'Checking this ID now. The next ID will start after its result is available.'
    );

    checkButton.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    checkButton.click();

    state.waitTimer = window.setInterval(() => {
      if (!state.isRunning || state.current?.accountId !== accountId) {
        return;
      }

      if (checkButton.disabled) {
        observedBusy = true;
      }

      // The original checker re-enables its button only after it receives a
      // result (or reports an error), which makes this a safe hand-off point.
      if (observedBusy && !checkButton.disabled) {
        completeCurrentCheck();
        return;
      }

      const elapsed = Date.now() - startedAt;
      const status = accountStatusText(checkButton);
      const hasImmediateResult = status && !/checking|loading|please wait/i.test(status);

      // Covers immediate errors where the original checker does not need to
      // disable the button (for example, a missing saved account).
      if (!observedBusy && elapsed > 750 && hasImmediateResult) {
        completeCurrentCheck();
        return;
      }

      // Do not start a second ID while an earlier check is still unresolved.
      if (elapsed >= CHECK_TIMEOUT_MS) {
        finish(
          `Paused at ${state.completed + 1}/${state.queue.length}`,
          'This ID did not finish in time. Review it, then start Check All IDs again.'
        );
      }
    }, 250);
  };

  const stopBatch = () => {
    if (!state.isRunning) {
      return;
    }

    const wasChecking = Boolean(state.current);
    const tabId = state.activeTabId;
    finish(
      `Stopped after ${state.completed}/${state.queue.length}`,
      wasChecking
        ? 'The current check was cancelled. No further IDs will be checked.'
        : 'No further IDs will be checked.'
    );

    // Each existing per-ID check opens its own IRCTC tab. Closing only the
    // tab created for the active batch item cancels that in-progress check.
    if (Number.isInteger(tabId) && chrome?.tabs?.remove) {
      chrome.tabs.remove(tabId).catch(() => {});
    }
  };

  // The original per-ID check opens one IRCTC tab. Remember that tab only
  // while a batch item is active so Stop can cancel the active item safely.
  if (chrome?.tabs?.onCreated) {
    chrome.tabs.onCreated.addListener((tab) => {
      if (
        state.isRunning &&
        state.current &&
        typeof tab.url === 'string' &&
        tab.url.includes('://www.irctc.co.in/')
      ) {
        state.activeTabId = tab.id;
      }
    });
  }

  startButton.addEventListener('click', () => {
    const queue = getCheckButtons()
      .filter((button) => !button.disabled)
      .map((button) => button.dataset.id)
      .filter(Boolean);

    if (!queue.length) {
      setMessage('Nothing to check', 'Add an ID first, or wait for the current manual check to finish.');
      return;
    }

    state.isRunning = true;
    state.queue = queue;
    state.index = 0;
    state.completed = 0;
    state.skipped = 0;
    state.current = null;
    updateControls();
    startNextCheck();
  });

  stopButton.addEventListener('click', stopBatch);
})();
